-- Active: 1780522161121@@127.0.0.1@3307@industria_db
insert into setores (nome, localizacao) values 
('Usinagem', 'Prédio A'),
('Soldagem', 'Prédio B'),
('Pintura', 'Prédio C'),
('Montagem', 'Prédio D'),
('Qualidade', 'Prédio E');

insert into funcionarios (nome, cpf, cargo, salario, data_admissao, id_setor) values 
('Rafael Matosso', '123.456.789-00', 'Engenheiro de Produção', 8000.00, '2020-01-15', 1),
('Maria Silva', '987.654.321-00', 'Técnico de Usinagem', 4000.00, '2019-03-10', 1),
('João Pereira', '456.789.123-00', 'Soldador', 3500.00, '2021-06-20', 2),
('Ana Souza', '789.123.456-00', 'Pintora', 3000.00, '2018-11-05', 3),
('Carlos Oliveira', '321.654.987-00', 'Montador', 3200.00, '2022-02-28', 4),
('Fernanda Lima', '654.321.789-00', 'Analista de Qualidade', 4500.00, '2017-08-12', 5),
('Pedro Santos', '111.222.333-44', 'Operador de Máquinas', 2800.00, '2020-09-01', 1),
('Luciana Costa', '555.666.777-88', 'Supervisor de Produção', 6000.00, '2019-12-15', 1),
('Ricardo Almeida', '999.888.777-66', 'Técnico de Soldagem', 3800.00, '2021-04-18', 2),
('Sofia Rodrigues', '444.333.222-11', 'Pintora Assistente', 2500.00, '2022-07-10', 3);

insert into produtos (codigo, nome, descricao, preco, )

insert into categorias (nome) values 
('Eletrônicos'),
('Móveis'),
('Alimentos'),
('Bebidas'),
('Roupas');

insert into fornecedores (razao_social, cnpj, telefone, cidade) values 
('Fornecedor A', '12.345.678/0001-90', '(11) 1234-5678', 'São Paulo'),
('Fornecedor B', '98.765.432/0001-10', '(21) 9876-5432', 'Rio de Janeiro'),
('Fornecedor C', '56.789.012/0001-34', '(31) 5678-9012', 'Belo Horizonte'),
('Fornecedor D', '34.567.890/0001-56', '(41) 3456-7890', 'Curitiba'),
('Fornecedor E', '78.901.234/0001-78', '(51) 7890-1234', 'Porto Alegre');